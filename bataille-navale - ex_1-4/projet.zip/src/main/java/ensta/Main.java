package ensta;

import ensta.controller.Game;

public class Main {

	public static void main(String args[]) {
        new Game().init().run();
    }

}
