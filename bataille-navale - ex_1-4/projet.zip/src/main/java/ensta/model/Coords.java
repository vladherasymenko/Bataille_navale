package ensta.model;

public class Coords {

	public Coords(Coords coords) {
		// TODO Auto-generated constructor stub
	}

	public Coords() {
		// TODO Auto-generated constructor stub
	}

	public int getX() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void setX(int i) {
		// TODO Auto-generated method stub
		
	}

	public int getY() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void setY(int i) {
		// TODO Auto-generated method stub
		
	}

}
