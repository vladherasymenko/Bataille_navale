package ensta.model.ship;

public class Destroyer {
	private static char label = 'D'; 
	private static String name = "Destroyer";
}
