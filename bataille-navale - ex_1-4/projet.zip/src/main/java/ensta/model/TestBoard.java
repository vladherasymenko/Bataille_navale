package ensta.model;

public class TestBoard {
	
}
